package com.abhay.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ServerArguments {

	List<String> argsList = new ArrayList<String>();
	Map<String,String> mapArgs = new HashMap<>();
	int port;
	public String rootFilePath;
	
	public ServerArguments(List<String> argsList, Map<String,String> mapArgs) {
		super();
		this.argsList = argsList;
		this.mapArgs = mapArgs;
		setInputs();
	}
	
	private void setInputs() {
		if(mapArgs.containsKey("port"))
			this.port = Integer.parseInt(mapArgs.get("port"));
		else
			throw new IllegalArgumentException("Port not provided");
		
		if(mapArgs.containsKey("directory"))
			this.rootFilePath = mapArgs.get("directory");
		else
			this.rootFilePath = ".";
	}

	public int getPort() {
		return port;
	}

	public String getRootFilePath() {
		return this.rootFilePath;
	}
	
	
	
}
