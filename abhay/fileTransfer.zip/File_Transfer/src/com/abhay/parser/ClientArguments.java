package com.abhay.parser;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClientArguments {

	List<String> argsList = new ArrayList<String>();
	Map<String, String> mapArgs = new HashMap<>();
	int port;
	String hostname;
	List<String> fileNames  = new ArrayList<>();
	String directory;
	private String clientID;

	public ClientArguments(List<String> argsList, Map<String, String> mapArgs) {
		super();
		this.argsList = argsList;
		this.mapArgs = mapArgs;
		setInputs();
	}

	private void setInputs() {
		if (mapArgs.containsKey("clientID"))
			this.clientID = mapArgs.get("clientID");
		else
			throw new IllegalArgumentException("--clientID argument not provided");
		if (mapArgs.containsKey("port"))
			this.port = Integer.parseInt(mapArgs.get("port"));
		else
			throw new IllegalArgumentException("--port argument not provided");
		if (mapArgs.containsKey("hostname"))
			this.hostname = mapArgs.get("hostname");
		else
			throw new IllegalArgumentException("--hostname argument not provided");
		if (mapArgs.containsKey("files")) {
			String filename = mapArgs.get("files");
			String[] filenames = filename.split(",");
			this.fileNames = Arrays.asList(filenames);
		}
/*		if (mapArgs.containsKey("directory")) {
			String filename = mapArgs.get("directory");
			String[] filenames = filename.split(",");
			this.fileNames = Arrays.asList(filenames);
		}*/
		if (mapArgs.containsKey("directory")) {
			this.directory = mapArgs.get("directory");
			File myFile = new File(this.directory);
			File [] dirFiles = myFile.listFiles();
			if(dirFiles == null ) {
				throw new IllegalArgumentException("No Files Found in directory " + this.directory);
			}
		}
		if ((this.directory == null || this.directory.isEmpty() == true)
				&& (this.fileNames == null || this.fileNames.isEmpty() == true)) {
			throw new IllegalArgumentException("File or directory not provided");
		}

	}

	public int getPort() {
		return port;
	}

	public String getHostname() {
		return hostname;
	}
	
	public String getClientId() {
		return clientID;
	}

	public List<String> getFileNames() {
		return fileNames;
	}

	public String getDirectory() {
		return directory;
	}
	
	

}
