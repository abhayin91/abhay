package com.abhay.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArgumentParser {
	List<String> argsList = new ArrayList<String>();
	Map<String,String> mapArgs = new HashMap<>();
	String[] args;
	
	

	public ArgumentParser(String[] args) {
		super();
		this.args = args;
	}

	public void parseArgument() {

		for (int i = 0; i < args.length; i++) {
			switch (args[i].charAt(0)) {
			case '-':
				if (args[i].length() < 2)
					throw new IllegalArgumentException("Not a valid argument: " + args[i]);
				if (args[i].charAt(1) == '-') {
					if (args[i].length() < 3)
						throw new IllegalArgumentException("Not a valid argument: " + args[i]);
					// --opt
					String arg = args[i].substring(2, args[i].length());
					String [] val = arg.split("=");
					if(val.length < 2) {
						throw new IllegalArgumentException("Expected arg after: " + val[0]+"=");
					}
					mapArgs.put(val[0], val[1]);
				} else {
					if (args.length - 1 == i)
						throw new IllegalArgumentException("Expected arg after: " + args[i]);
					// -opt
					// optsList.add(new Option(args[i], args[i+1]));
					i++;
				}
				break;
			default:
				// arg
				if(argsList.isEmpty())
					argsList.add(args[i]);
				else
					throw new IllegalArgumentException("argument " + argsList.toString()+" already specified");
				break;
			}

		}
	}
	
	public List<String> getAgrs(){
		return this.argsList;
	}

	public Map<String, String> getMapArgs() {
		return mapArgs;
	}
	
	
}
