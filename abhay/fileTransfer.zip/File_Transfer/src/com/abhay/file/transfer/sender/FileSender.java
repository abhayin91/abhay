package com.abhay.file.transfer.sender;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.abhay.file.connection.SocketConnection;
import com.abhay.file.exceptions.ConnectionException;

public class FileSender {
	private static final Logger logger = Logger.getLogger(FileSender.class.getName());

	private SocketConnection sockCon;
	private List<File> files;
	String clientId;

	public FileSender(SocketConnection sockCon, List<File> files, String clientId) {
		super();
		setSockCon(sockCon);
		setFiles(files);
		this.clientId = clientId;
	}

	/**
	 * Main logic to download file from input stream<br> 
	 * <b>Protocol : </b><br>
	 * Step 1 - send clientID.<br>
	 * Step 2 - send number of files to be received. <br>
	 * Step 3 - send file name of all files to be received.<br>
	 * Step 4 - send file size per file.<br>
	 * Step 5 - send data per file.<br>
	 * 
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public void sendFile() throws ConnectionException, IOException, FileNotFoundException {
		OutputStream os = this.sockCon.getOutputStream();
		DataOutputStream dos = new DataOutputStream(os);
		String clientId = this.clientId;
		//Step 1 - send clientID.
		dos.writeUTF(clientId);
		File[] allFiles = (File[]) this.files.toArray(new File[0]);
		// Step 2 - send number of files to be received.
		dos.writeInt(allFiles.length);
		// Step 3 - send file name of all files to be received.
		for (int count = 0; count < allFiles.length; count++) {
			dos.writeUTF(allFiles[count].getName());

		}
		// send size of every file so that server writes data of exact amount in each
		// file
		//Step 4 - send file size per file.
		for (int count = 0; count < allFiles.length; count++) {

			int filesize = (int) allFiles[count].length();
			dos.writeInt(filesize);
		}
		//Step 5 - send data per file.
		for (int count = 0; count < allFiles.length; count++) {

			int filesize = (int) allFiles[count].length();
			byte[] buffer = new byte[filesize];

			// FileInputStream fis = new FileInputStream(myFile);
			String dispachingFile = allFiles[count].toString();
			logger.log(Level.INFO, "Sending file : " + dispachingFile);
			Instant start = Instant.now();
			FileInputStream fis = new FileInputStream(dispachingFile);
			BufferedInputStream bis = new BufferedInputStream(fis);

			// Sending file name and file size to the server
			// read file from disk and populate the buffer
			bis.read(buffer, 0, buffer.length); // This line is important
			// write populated buffer to server encuring same data is been sent to the
			// server
			dos.write(buffer, 0, buffer.length);
			dos.flush();
			bis.close();
			Instant end = Instant.now();
			Duration timeElapsed = Duration.between(start, end);
			logger.log(Level.INFO, "File sent : " + dispachingFile + " Time taken is "+ timeElapsed.toMillis()+" milliseconds");
			// dos.close(); do not close the connection here as we still have to send more
			// files
		}
		this.sockCon.closeConnection();
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public void setSockCon(SocketConnection sockCon) {
		this.sockCon = sockCon;
	}

}
