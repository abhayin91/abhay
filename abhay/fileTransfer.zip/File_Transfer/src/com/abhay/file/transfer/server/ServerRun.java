package com.abhay.file.transfer.server;

import java.io.IOException;
import java.io.InputStream;

import com.abhay.file.connection.ConnectionManager;
import com.abhay.file.connection.ServerConnection;
import com.abhay.file.exceptions.ConnectionException;
import com.abhay.file.transfer.reciever.FileReveiver;

/**
 * run server to listen socket connection for a given port
 */
public class ServerRun {

	/** run server , accept connection , download files, etc
	 * <b>Assumption : server will always listen for new connection and can only be stopped by keyboard kill</b>
	 * @throws ConnectionException
	 */
	public static void run(String rootFileLocation, int port) throws ConnectionException {
		String filePath = rootFileLocation;
		//boolean whileFlag = true;
		ServerConnection serverSocket = ConnectionManager.getServerConnection(port);
		// always listen for new connections
		serverSocket.acceptConnection();
		while (true) { // always listen
			InputStream in = serverSocket.getInputStream();
			FileReveiver rf = new FileReveiver(in, filePath);
			try {
				rf.receiveFile();
			} catch (IOException e) {
				//close connection
				serverSocket.closeConnection();
				throw new ConnectionException(e.getMessage(),105,e);
			}
			serverSocket.acceptConnection(); // start accepting new connection

		} 

	}

}
