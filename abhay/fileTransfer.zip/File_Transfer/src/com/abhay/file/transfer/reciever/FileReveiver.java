package com.abhay.file.transfer.reciever;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.abhay.file.exceptions.ConnectionException;

/**
 * Class to receive file for provided input stream and saves file to the specified file path.
 * @author Abhay.Singh
 *
 */
public class FileReveiver {
	private static final Logger logger =
	        Logger.getLogger(FileReveiver.class.getName());
	private InputStream in;
	private String filePath;

	public FileReveiver(InputStream in, String filePath) throws ConnectionException {
		super();
		setIn(in);
		setFilePath(filePath);
	}

	private void setIn(InputStream in) throws ConnectionException {
		if (in == null) {
			throw new ConnectionException("Input stream is null", 103);
		}
		this.in = in;
	}

	private void setFilePath(String filePath) throws ConnectionException {
		if (filePath == null || filePath.isEmpty()) {
			throw new ConnectionException("file path is null or empty", 104);
		}
		this.filePath = filePath;
	}
	
	/**
	 * Main logic to download file from input stream<br> 
	 * <b>Protocol : </b><br>
	 * Step 1 - get clientID.<br>
	 * Step 2 - get number of files to be received <br>
	 * Step 3 - get file name of all files to be received<br>
	 * Step 4 - get file size per file<br>
	 * Step 5 - get data per file<br>
	 * 
	 * @return
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public boolean receiveFile() throws IOException, FileNotFoundException {
		boolean whileFlag = true;
		BufferedOutputStream bos;
		OutputStream output;
		DataOutputStream dos;
		int len;
		int smblen;
		DataInputStream clientData;
		clientData = new DataInputStream(this.in); // use

		logger.log(Level.INFO, "Starting file download");
		// Step 1 - get clientID.
		String clientId = clientData.readUTF();
		// save files per client in client directory
		createDirectory(clientId);
		StringBuilder fileDirectory = getFileDirectory(clientId);
		logger.log(Level.INFO, "Starting file download at Client Directory : " + fileDirectory.toString());
		// Step 2 - get number of files to be received
		int fileCount = clientData.readInt();

		ArrayList<File> files = new ArrayList<File>(fileCount); // place store list of file from client directory
		ArrayList<Integer> fileSize = new ArrayList<Integer>(fileCount); // place to store file size from client
		// Assumption : sequence in which file name and file size is to be sent is
		// pre-determined.
		// Start to accept those filename from server
		//Step 3 - get file name of all files to be received
		for (int count = 0; count < fileCount; count++) {
			File ff = new File(clientData.readUTF());
			files.add(ff);
		}

		for (int count = 0; count < fileCount; count++) {
			// Step 4 - get file size per file
			fileSize.add(clientData.readInt());
		}

		for (int count = 0; count < fileCount; count++) {

			if (fileCount - count == 1) {
				whileFlag = false; // this is the last file so need to rerun this loop
			}

			len = fileSize.get(count);
			logger.log(Level.INFO, "File Size = " + len);
			StringBuilder sb = new StringBuilder(fileDirectory.toString());
			sb.append(File.separator);
			sb.append(files.get(count));
			logger.log(Level.INFO, "downloading file at " + sb.toString());
			Instant start = Instant.now();
			output = new FileOutputStream(sb.toString());
			dos = new DataOutputStream(output);
			bos = new BufferedOutputStream(output);
			// we could also try to set buffer size to the length of file
			//byte[] buffer = new byte[len];
			byte[] buffer = new byte[2048];

			bos.write(buffer, 0, buffer.length); 
			// Step 5 : get data per file
			while (len > 0 && (smblen = clientData.read(buffer)) > 0) {
				dos.write(buffer, 0, smblen);
				len = len - smblen; // Subtract data which is written to file
				dos.flush();// write data per buffer
			}
			// alternatively we can do it as below
			//clientData.read(buffer, 0, buffer.length); // This line is important
			// write populated buffer to server ensuring same data is been sent to the
			// server
			/*dos.write(buffer, 0, buffer.length);
			dos.flush();*/
			dos.close(); // close file stream
			Instant end = Instant.now();
			Duration timeElapsed = Duration.between(start, end);
			logger.log(Level.INFO, "file downloaded at " + sb.toString() + "  Time taken : "+timeElapsed.toMillis() + " milliseconds");
			//logger.log(Level.INFO, "file downloaded at " + sb.toString());
		}
		return whileFlag;
	}

	private void createDirectory(String clientId) {
		StringBuilder sb = getFileDirectory(clientId);
		new File(sb.toString()).mkdirs();
	}

	private StringBuilder getFileDirectory(String clientId) {
		StringBuilder sb = new StringBuilder(this.filePath);
		sb.append(File.separator);
		sb.append(clientId);
		return sb;
	}
}
