package com.abhay.file.transfer.client;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.abhay.file.connection.ConnectionManager;
import com.abhay.file.connection.SocketConnection;
import com.abhay.file.exceptions.ConnectionException;
import com.abhay.file.transfer.sender.FileSender;

public class ClientRun {
	private static final Logger logger =
	        Logger.getLogger(ClientRun.class.getName());

	/**
	 * @param args
	 * @throws ConnectionException
	 */
	public static void run(String host, int port,String directory , List<String> files, String clientID) throws ConnectionException {

		SocketConnection sockCon = ConnectionManager.getSocketConnection(host, port); // replace with your remote																				// host static IP
																								// address.
		String directoryPath = directory;
		List<File> files1 = getFileslist(files);
		List<File> files2 = getAllFilesFromDirectory(directoryPath);
		files1.addAll(files2);
		FileSender fs = new FileSender(sockCon, files1,clientID);
		try {
			fs.sendFile();
		} catch (IOException e) {
			logger.log(Level.INFO, "Could not send file, please fix error and try again");
			logger.log(Level.SEVERE, e.getMessage(),e);
			
		}finally {
			// close connection no matter what.
				sockCon.closeConnection();
		}

	}

	private static List<File> getAllFilesFromDirectory(String directoryPath) throws ConnectionException {
		File myFile = new File(directoryPath);
		File [] dirFiles = myFile.listFiles();
		if(dirFiles == null ) {
			logger.log(Level.SEVERE, "No files found in directory : " + directoryPath);
			throw new ConnectionException("No Files Found in directory " + directoryPath,107);
		}
		List<File> files = Arrays.asList(dirFiles);
		if (files==null)
			files = new ArrayList<File>();
		return files;
	}
	
	private static List<File> getFileslist(List<String> files) {
		List<File> fileArray = new ArrayList<>();
		for (String fileName : files) {
			File myFile = new File(fileName);
			fileArray.add(myFile);
			
		}
		return fileArray;
	}

}