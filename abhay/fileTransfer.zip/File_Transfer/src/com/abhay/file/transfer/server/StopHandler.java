package com.abhay.file.transfer.server;

import java.util.Scanner;

public class StopHandler implements Runnable {

	public static boolean STOPSERVER = false;
	@Override
	public void run() {
		Scanner scn = new Scanner(System.in);
		String s = scn.next();
		while (true) {
			if ("stop".equalsIgnoreCase(s)) {
				System.out.println("stopping server on Next request");
				StopHandler.STOPSERVER = true;
			}
			s = scn.next();
		}
	}

}
