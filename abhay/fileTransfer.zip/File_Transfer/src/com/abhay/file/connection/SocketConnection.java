package com.abhay.file.connection;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.abhay.file.exceptions.ConnectionException;

public class SocketConnection {
	
	private static final Logger logger =
	        Logger.getLogger(SocketConnection.class.getName());

	String host;
	int port;
	Socket socket;
	OutputStream outputStream;

	public SocketConnection(String host, int port) {
		super();
		this.host = host;
		this.port = port;
	}

	public Socket getSocket() {
		return this.socket;
	}

	public OutputStream getOutputStream() throws ConnectionException {
		try {
			this.outputStream = this.socket.getOutputStream();
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Could not get output stream : " + this.port);
			throw new ConnectionException("Could not get output stream", 102, e);
		}
		return this.outputStream;
	}

	public SocketConnection connect() throws ConnectionException {

		try {
			logger.log(Level.INFO, "trying to establish connection on host: "+this.host+" Port : " + this.port);
			this.socket = new Socket(this.host, this.port);
			logger.log(Level.INFO, "connection established on host: "+this.host+" Port : " + this.port);
			return this;
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Could not establish connection on host: "+this.host+" Port : " + this.port);
			throw new ConnectionException("Could not establish connection", 100, e);
		}

	}
	
	public void closeConnection() {
		
		if (this.socket.isClosed() == false) {
			
			try {
				this.socket.close();
				logger.log(Level.INFO, "closing socket connection");
			} catch (IOException e) {
				logger.log(Level.SEVERE, "Error in closing socket connection",e);
			}
		}
	}

}
