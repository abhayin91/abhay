package com.abhay.file.connection;

import com.abhay.file.exceptions.ConnectionException;

public class ConnectionManager {
	
	
	public static SocketConnection getSocketConnection(String host, int port) throws ConnectionException {
		SocketConnection sc = new SocketConnection(host, port);
		return sc.connect();
	}
	
	
	public static ServerConnection getServerConnection(int port) throws ConnectionException {
		ServerConnection sc = new ServerConnection(port);
		return sc.connect();
	}	

}
