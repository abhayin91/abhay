package com.abhay.file.connection;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.abhay.file.exceptions.ConnectionException;
import com.abhay.file.transfer.server.StopHandler;

public class ServerConnection {
	
	private static final Logger logger =
	        Logger.getLogger(ServerConnection.class.getName());
	
	int port;
	ServerSocket serverSocket;
	InputStream inputStream;
	Socket socket;

	public ServerConnection(int port) {
		super();
		this.port = port;
	}
	

	
	public InputStream getInputStream() throws ConnectionException {
		try {
			if (this.socket.isInputShutdown() == false) {
				this.inputStream = this.socket.getInputStream();
			}else {
				logger.log(Level.SEVERE, "Input Stram is Shoutdown can not get input stream : " + this.port);
				throw new ConnectionException("Input Stram is Shoutdown can not get input stream", 103);
			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Could not get input stream : " + this.port);
			throw new ConnectionException("Could not get input stream", 102, e);
		}
		return inputStream;
	}



	public ServerConnection connect() throws ConnectionException {

		try {
			this.serverSocket = new ServerSocket(this.port);
			logger.log(Level.INFO, "created server socket on Port : " + this.port);
			return this;
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Could not establish connection on Port : " + this.port);
			throw new ConnectionException("Could not establish connection"+ e.getMessage(), 100, e);
		}

	}
	/**
	 * handles new connection as well as stops server if command issue by keyboard
	 * @throws ConnectionException
	 */
	public void acceptConnection() throws ConnectionException {
		try {
			boolean connectionFound = false;
			// wait for new connection
			while (!connectionFound) {
				this.serverSocket.setSoTimeout(30000);
				try {
					logger.log(Level.INFO, "accepting  new connection");
					this.socket = this.serverSocket.accept();
					connectionFound = true;
					logger.log(Level.INFO, "Connection found");
				} catch (SocketTimeoutException e) {
					logger.log(Level.INFO, "Server is idle, waiting for new connection");
					if (StopHandler.STOPSERVER) {
						logger.log(Level.INFO, "Stoping Server ....");
						this.serverSocket.close();
						logger.log(Level.INFO, "Server stopped ....");
						System.exit(0);
					}
				}
			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, "could not accept connection", e);
			throw new ConnectionException("could not accept connection", 101, e);
		}
	}
	
	public void closeConnection() {
		
		if (this.serverSocket.isClosed() == false) {
			
			try {
				this.serverSocket.close();
			} catch (IOException e) {
				logger.log(Level.SEVERE, "Error in closing socket connection",e);
			}
		}
	}


	
}
