package com.abhay.file.descriptor;

import com.abhay.file.exceptions.ConnectionException;
import com.abhay.file.transfer.client.ClientRun;
import com.abhay.file.transfer.server.ServerRun;
import com.abhay.file.transfer.server.StopHandler;
import com.abhay.parser.ArgumentParser;
import com.abhay.parser.ClientArguments;
import com.abhay.parser.ServerArguments;
/**
 * Application entry point.
 * @author Abhay.Singh
 *
 */
public class FileDescriptor {
	
	public static void main(String[] args) {
		ArgumentParser parser = new ArgumentParser(args);
		parser.parseArgument();
		System.out.println(parser.getAgrs().toString());
		System.out.println(parser.getMapArgs().toString());
		if(parser.getAgrs().isEmpty()) {
			throw new IllegalArgumentException("Please provide supported command type : server | client");
		}
		switch (parser.getAgrs().get(0)) {
		case "server":
			ServerArguments sa = new ServerArguments(parser.getAgrs(), parser.getMapArgs());
			// start thread to stop server on keyboard "stop" input
			startServerStopHandler();
			try {
				ServerRun.run(sa.getRootFilePath(), sa.getPort());
			} catch ( ConnectionException e) {
				e.printStackTrace();
			}
			break;
		case "client":
			ClientArguments ca = new ClientArguments(parser.getAgrs(), parser.getMapArgs());
			try {
				ClientRun.run(ca.getHostname(), ca.getPort(),ca.getDirectory(), ca.getFileNames() , ca.getClientId());
			} catch (ConnectionException e) {
				e.printStackTrace();
			}
			break;

		default:
			throw new IllegalArgumentException("Please provide supported command type : server | client");
		}
		
	}

	private static void startServerStopHandler() {
		Thread stopServer = new Thread(new StopHandler());
		stopServer.start();
	}

}
