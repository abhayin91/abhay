package com.abhay.file.exceptions;

public class ConnectionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	String message;
	int errorCode;
	Exception e;
	
	public ConnectionException(String message, int errorCode, Exception e) {
		super();
		this.message = message;
		this.errorCode = errorCode;
		this.e = e;
	}
	

	public ConnectionException(String message, int errorCode) {
		super();
		this.message = message;
		this.errorCode = errorCode;
	}



	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public Exception getException() {
		return e;
	}

	public void setException(Exception e) {
		this.e = e;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		if(this.e!= null) {
			this.e.printStackTrace();
		}
		return super.toString();
	}
	
	
	
	

}
