package com.abhay.file.descriptor;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.abhay.file.transfer.server.StopHandler;

public class MainTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAsServer() {
		ArrayList<String> allArgs = new ArrayList<>();
		allArgs.add("server");
		allArgs.add("--port=9885");
		StopHandler.STOPSERVER=true;
		FileDescriptor.main(allArgs.toArray(new String[0]));
		StopHandler.STOPSERVER=false;
		// if server stops gracefully
		assertTrue(true);
	}
	
	@Test
	public void testAsClient() {
		ArrayList<String> allArgs = new ArrayList<>();
		allArgs.add("server");
		allArgs.add("--port=9876");
		StopHandler.STOPSERVER=false;
		runServerInNewThread(allArgs);
		allArgs = new ArrayList<>();
		allArgs.add("client");
		allArgs.add("--hostname=127.0.0.1");
		allArgs.add("--port=9876");
		allArgs.add("--clientID=abhay_1");
		allArgs.add("--directory=resources");
		FileDescriptor.main(allArgs.toArray(new String[0]));
		//StopHandler.STOPSERVER=false;
		StopHandler.STOPSERVER=true;
		assertTrue(true);
		
		
	}
	
	public void runServerInNewThread(ArrayList<String> allArgs) {
		Thread server = new Thread(new Runnable() {
			public void run() {
				FileDescriptor.main(allArgs.toArray(new String[0]));
			}
		});
		server.start();
	}

}
